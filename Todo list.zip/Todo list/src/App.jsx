import React, { useState } from 'react'

const App = () => {
  const [todos, setTodos] = useState([]);
  const [task, setTask] = useState('');
  const [editingId, setEditingId] = useState(null);

  const handleDelete = (id) => {
    const filterTodos = todos.filter(todo => todo.id !== id);
    setTodos(filterTodos);
  }

  const handleAddTask = (e) => {
    e.preventDefault();

    if(!task.trim()) return;

    if(editingId) {
      // edit mode
      const updateTodos = todos.map(todo => todo.id === editingId ? {...todo, text:task} : todo)
      setTodos(updateTodos);
      setEditingId(null);
    } else {
      const newTodo = {
      id: Date.now(),
      text: task
    }
    setTodos([...todos, newTodo])
    }
    setTask('')
  }


  return (
    <div className='container mt-5'>
      <h2 className='text-center mb-4'>Todo List</h2>
      <form onSubmit={handleAddTask} className='d-flex mb-4 col-md-6 offset-md-3'>
        <input
          type="text"
          className='form-control me-2'
          placeholder='Enter a task'
          value={task}
          onChange={(e) => setTask(e.target.value)}
        />
        <button className='btn btn-primary'>
          {editingId ? 'Update' : 'Add'}
        </button>
      </form>

      
      <ul className='list-group col-md-6 offset-md-3'>
  {todos.length === 0 ? (
    <li className='list-group-item text-center text-muted'>
      No tasks yet
    </li>
  ) : (
    todos.map((todo, index) => (
      <li key={todo.id} className='list-group-item d-flex justify-content-between align-items-center'>
        <span>{index + 1}. {todo.text}</span>
        <div>
          <button className='btn btn-warning btn-sm me-2'
          onClick={() => [
            setTask(todo.text),
            setEditingId(todo.id)
          ]}
          >Edit</button>
          <button className='btn btn-danger btn-sm' onClick={() => handleDelete(todo.id)}>Delete</button>
        </div>
      </li>
    ))
  )}
</ul>

    </div>
  )
}

export default App